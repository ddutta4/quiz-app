# Quiz_application
Welcome to this repository, in this repository you'll find a simple quiz application which is built using HTML, CSS and JavaScript
