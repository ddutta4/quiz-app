
//Array of objects(qustions)


const quiz =[
{
	q:'Is HTML a programming language?',
	options:['Yes','No'],
	answer:1
},
{
	q:'What is one of the reasons Java is different to Javascript?',
	options:['Java is compiled before it runs and isn\'t limited to being on a web browser.','Java is just short for javascript','Javascript is barely used anymore since Java came out.'],
	answer:0
},
{
	q:'What is the newest version of HTML being developed?',
	options:['HTML4','HTML6','HTML5','There is only one type of HTML'],
	answer:2
},
{
	q:'What does CSS stand for?',
	options:['Complete Sound Sheet','Cascading Style Sheet','Cscading Style Syntax'],
	answer:1
},
{
	q:'Non animated gifs are usually lower in file size, why don\'t people use them for photos',
	options:["Because it hasn't caught on.",'You need to pay for a lisencse to use them.','They are distracting and decrease Usability.','None of the above'],
	answer:2
},
{
	q:"What happens to a lot of images saved as jpgs when you put them online.",
	options:['Stretching',"They'll turn blur",'They are too big in file size.','Lower quality and artifacts.'],
	answer:3
},
{
	q:"Which is the correct CSS syntax?",
	options:["Body {color: black}","{body;color:black}","{body:color=black(body}","body:color=black"],
	answer:0
},
{
	q:"What does a compiler do?   ",
	options:["Makes code start","Tests to see whether the program runs fine","Converts the coding into another computer language, usually to make an executable program."],
	answer:2
},
{
	q:"What is an advantage of having external CSS?",
	options:["It is faster","You can edit one file to edit the base of every page which uses it.","It makes no difference"],
	answer:1
},
{
	q:"What does the acronym WWW stand for?",
	options:["Wide Wacky Walter","Web Wide Wave","Wide Wall Web","Web World Wall","World Wide Web"],
	answer:4
},
{
	q:"HTML uses______?",
	options:["User defined tags","Pre-specified tags","Fixed tags defined by the language","Tags only for linking"],
	answer:2
},
{
	q:"The year in which HTML was first proposed _______?",
	options:["1993","2001","1951","1890"],
	answer:0
}
]

